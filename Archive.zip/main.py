# main.py
import time
from selenium.webdriver.common.by import By
from data import *
from helpers import *
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from orig_pages import UrbanRoutesPage

# driver.implicitly_wait(3)
# driver.find_element(By.TAG_NAME, "button")
# driver.find_element(By.TAG_NAME, "div")
# driver.find_element(By.TAG_NAME, "button")
# driver.find_element(By.TAG_NAME, "imput")
# driver.find_element(By.ID, "from").send_keys("East 2nd Street, 601")
# driver.find_element(By.ID, "to").send_keys("1300 1st St")
# driver.find_element(By.ID, "from").clear()
# driver.find_element(By.CLASS_NAME, "logo-disclaimer").text

class TestUrbanRoutes:
    driver = webdriver.Chrome()

    @classmethod
    def setup_class(cls):
      if is_url_reachable(URBAN_ROUTES_URL):
          # do not modify - we need additional logging enabled in order to retrieve phone confirmation code
          from selenium.webdriver import DesiredCapabilities
          capabilities = DesiredCapabilities.CHROME
          capabilities["goog:loggingPrefs"] = {'performance': 'ALL'}
          cls.driver = webdriver.Chrome()
      else:
          assert is_url_reachable(URBAN_ROUTES_URL), "Urban Routes URL is unreachable"

    def test_set_route(self):
        self.driver.get(URBAN_ROUTES_URL)

        # Create an instance of the page class
        self.urban_routes_page = UrbanRoutesPage(self.driver)

        self.urban_routes_page.enter_from_location(ADDRESS_FROM)main.py
        self.urban_routes_page.enter_to_location(ADDRESS_TO)


    def test_from_address_input(self):
        # Retrieve input field text values
        from_actual_value = self.urban_routes_page.get_from_location_text()
        assert ADDRESS_FROM in from_actual_value, f"Expected '{ADDRESS_FROM}', but got '{from_actual_value}'"

    def test_to_address_input(self):
        to_actual_value = self.urban_routes_page.get_from_location_text()
        assert ADDRESS_TO in to_actual_value, f"Expected '{ADDRESS_TO}', but got '{to_actual_value}'"

    def test_select_plan(self):
        # Add in S8
        print("function created for select plan")
        pass

    def test_fill_phone_number(self):
        # Add in S8
        print("function created for fill phone number")
        pass

    def test_fill_card(self):
        # Add in S8
        print("function created for fill card")
        pass

    def test_comment_for_driver(self):
        # Add in S8
        print("function created for comment for driver")
        pass

    def test_order_blanket_and_handkerchiefs(self):
        # Add in S8
        print("function created for order blanket and handkerchiefs")
        pass

    def test_order_2_ice_creams(self):
        # Add in S8
        print("function created for order 2 ice creams")
        for _ in range(2):
            # Add in S8
            pass

    def test_car_search_model_appears(self):
        # Add in S8
        print("function created for car search model appears")
        pass

    @classmethod
    def teardown_class(cls):
        cls.driver.quit()