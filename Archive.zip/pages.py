from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class UrbanRoutesPage:

    # Address Locators
    FROM_LOCATOR = (By.ID, 'from')
    TO_LOCATOR = (By.ID, 'to')

    # Taxi Locators
    TAXI_ICON_LOCATOR = (By.XPATH, '//img[@src="/static/media/taxi.2737d9c7.svg"]')
    TAXI_ACTIVE_ICON_LOCATOR = (By.XPATH, '//img[@src="/static/media/taxi-active.b0be3054.svg"]')
    CALL_TAXI_BUTTON = (By.XPATH, "//button[contains(@class, 'button') and contains(@class, 'round')]")

    # Tariff Locators
    SUPPORTIVE_TARIFF_LOCATOR = (By.XPATH, '//div[contains(@class, "tcard")][.//div[text()="Support"]]')
    ACTIVE_TARIFF_LOCATOR = (By.XPATH, '//div[@class="tcard active"]//div[@class="tcard-title"]')

    # Phone Locators
    PHONE_INPUT = (By.ID, 'phone')
    PHONE_NEXT_BUTTON = (By.XPATH, '//button[text()="Next"]')

    # SMS Code Locators
    SMS_CODE_INPUT = (By.ID, 'code')
    CODE_CONFIRM_BUTTON = (By.XPATH, '//button[text()="Confirm"]')
    CODE_RESEND_BUTTON = (By.XPATH, '//button[text()="Send the code again"]')

    # Payment Method Locators
    PAYMENT_METHOD_BUTTON = (By.CLASS_NAME, 'pp-button')
    PAYMENT_METHOD_VALUE_TEXT = (By.CLASS_NAME, 'pp-value-text')
    CASH_CHECKBOX = (By.ID, 'cash')
    ADD_CARD_ROW = (By.XPATH, '//div[contains(@class, "pp-row disabled")]')
    CARD_PLUS_BUTTON = (By.CLASS_NAME, 'pp-plus')

    # Card Locators
    CARD_NUMBER_INPUT = (By.ID, 'number')
    CARD_CODE_INPUT = (By.ID, 'code')
    CARD_LINK_BUTTON = (By.XPATH, '//button[text()="Link"]')
    CARD_CANCEL_BUTTON = (By.XPATH, '//button[text()="Cancel"]')

    # Driver Message Locator
    DRIVER_MESSAGE_INPUT = (By.ID, 'comment')

    # Blanket Locators
    BLANKET_TOGGLE = (By.XPATH, '//div[contains(text(), "Blanket and handkerchiefs")]/following::input[@type="checkbox"]')
    BLANKET_STATE_CHECK = (By.XPATH, '//div[contains(text(), "Blanket and handkerchiefs")]/ancestor::div[contains(@class, "r-sw-container")]//input')

    # Ice Cream Locators
    ICE_CREAM_PLUS_BUTTON = (By.XPATH, '//div[contains(@class, "r-counter-label") and text()="Ice cream"]/following::div[@class="counter-plus"]')
    ICE_CREAM_VALUE = (By.XPATH, '//div[contains(@class, "r-counter-label") and text()="Ice cream"]/following::div[@class="counter-value"]')

    # Order Items Locators
    ORDER_BUTTON = (By.XPATH, '//span[contains(text(), "Enter the number and order")]/ancestor::button')
    SEARCH_MODAL_TEXT = (By.XPATH, '//div[@class="results-text"]//div[@class="text"]')

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)

    def set_address_from(self, from_text):
        self.driver.find_element(*self.FROM_LOCATOR).send_keys(from_text)

    def set_address_to(self, to_text):
        # Enter To
        self.driver.find_element(*self.TO_LOCATOR).send_keys(to_text)

    def get_address_from(self):
        return self.driver.find_element(*self.FROM_LOCATOR).get_attribute('value')

    def get_address_to(self):
        return self.driver.find_element(*self.TO_LOCATOR).get_attribute('value')

    def get_taxi_icon(self):
        return self.driver.find_element(*self.TAXI_ICON_LOCATOR).get_attribute('src')

    def get_taxi_active_icon(self):
        return self.driver.find_element(*self.TAXI_ACTIVE_ICON_LOCATOR).get_attribute('src')

    def select_taxi_icon(self):
        button = self.wait.until(EC.element_to_be_clickable(self.TAXI_ICON_LOCATOR))
        button.click()

    def select_call_taxi_icon(self):
        button = self.wait.until(EC.element_to_be_clickable(self.CALL_TAXI_BUTTON))
        button.click()

    def select_supportive_tariff(self):
        button = self.wait.until(EC.element_to_be_clickable(self.SUPPORTIVE_TARIFF_LOCATOR))
        button.click()

    def get_active_tariff(self):
        return self.driver.find_element(*self.ACTIVE_TARIFF_LOCATOR).text
        # return self.wait.until(EC.presence_of_element_located(self.ACTIVE_TARIFF_LOCATOR)).text

    def enter_phone_number(self, number):
        phone_input = self.wait.until(EC.presence_of_element_located(self.PHONE_INPUT))
        phone_input.clear()
        phone_input.send_keys(number)

    def click_next_after_phone(self):
        self.wait.until(EC.element_to_be_clickable(self.PHONE_NEXT_BUTTON)).click()

    def enter_sms_code(self, code):
        sms_input = self.wait.until(EC.presence_of_element_located(self.SMS_CODE_INPUT))
        sms_input.clear()
        sms_input.send_keys(code)

    def confirm_sms_code(self):
        self.wait.until(EC.element_to_be_clickable(self.CODE_CONFIRM_BUTTON)).click()

    def click_payment_method(self):
        self.wait.until(EC.element_to_be_clickable(self.PAYMENT_METHOD_BUTTON)).click()

    def get_payment_method_text(self):
        return self.wait.until(EC.presence_of_element_located(self.PAYMENT_METHOD_VALUE_TEXT)).text

    def click_add_card_plus(self):
        self.wait.until(EC.element_to_be_clickable(self.CARD_PLUS_BUTTON)).click()

    def fill_card_number(self, number):
        el = self.wait.until(EC.presence_of_element_located(self.CARD_NUMBER_INPUT))
        el.clear()
        el.send_keys(number)

    def fill_card_code(self, code):
        el = self.wait.until(EC.presence_of_element_located(self.CARD_CODE_INPUT))
        el.clear()
        el.send_keys(code)

    def link_card(self):
        self.wait.until(EC.element_to_be_clickable(self.CARD_LINK_BUTTON)).click()

    def cancel_card_linking(self):
        self.wait.until(EC.element_to_be_clickable(self.CARD_CANCEL_BUTTON)).click()

    def enter_driver_message(self, message):
        el = self.wait.until(EC.presence_of_element_located(self.DRIVER_MESSAGE_INPUT))
        el.clear()
        el.send_keys(message)

    def toggle_blanket_option(self):
        toggle = self.wait.until(EC.element_to_be_clickable(self.BLANKET_TOGGLE))
        toggle.click()

    def is_blanket_selected(self):
        return self.wait.until(EC.presence_of_element_located(self.BLANKET_STATE_CHECK)).is_selected()

    def increase_ice_cream(self):
        self.wait.until(EC.element_to_be_clickable(self.ICE_CREAM_PLUS_BUTTON)).click()

    def get_ice_cream_value(self):
        return self.wait.until(EC.presence_of_element_located(self.ICE_CREAM_VALUE)).text

    def click_order_button(self):
        self.wait.until(EC.element_to_be_clickable(self.ORDER_BUTTON)).click()

    def get_search_modal_text(self):
        return self.wait.until(EC.presence_of_element_located(self.SEARCH_MODAL_TEXT)).text
